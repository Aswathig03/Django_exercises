from django.urls import path
from .import views

urlpatterns = [
    path('',views.home,name="home"),
    path('about/',views.about,name="about"),
    path('numericaloperations/',views.numericaloperations,name="numericaloperations"),
    path('agecalc/',views.agecalc,name="agecalc"),
    path('signup/', views.register, name='signup'),
    path('send_email/', views.send_email, name='send_email'),
    path('set_session/', views.set_session, name='set_session'),
    path('get_session/', views.get_session, name='get_session'),
    path('set_cookie/', views.set_cookie, name='set_cookie'),
    path('get_cookie/', views.get_cookie, name='get_cookie'),
    path('create/', views.create, name='create'),
    path('read/', views.read, name='read'),
    path('update/<int:pk>/', views.update, name='update'),
    path('delete/<int:pk>/', views.delete, name='delete'),
]

