from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse
from .forms import UserRegistrationForm
from .models import MyModel

from django.core.mail import send_mail
from django.conf import settings
# Create your views here.

def home(response):
    return HttpResponse("<h1>Home Page</h1><br> This is home page <br> Subject code:VIT326<br> Subject Name:Web Application Development using Django framework")

def about(response):
    return HttpResponse("<h1>About Page</h1><br>Name: Kabilesh<br>Roll No:21UIT033 ")

def numericaloperations(request):
    if request.method == 'POST':
        number_list = int(request.POST.get('number_list', 0))
        data = "Generation of Even Numbers"
        return render(request, 'operation.html', {'number_list': number_list}) 
    return render(request, "operation.html") 
    
def set_session(request):
    request.session['fname'] = 'Aswathi'
    return HttpResponse("Session data set")


def get_session(request):
    fname1 = request.session.get('fname', 'User')
    return HttpResponse(f"Session data: {fname1}")


def set_cookie(request):
    response = HttpResponse("Cookie set")
    response.set_cookie('fname', 'Aswathi')
    return response


def get_cookie(request):
    fname1 = request.COOKIES.get('fname', 'default_cookie_value')
    return HttpResponse(f"Cookie value: {fname1}")

def agecalc(request):
    if request.method == 'POST': 
      # Get the age from the form 
        age = int(request.POST.get('age', 0))   
        return render(request, 'age.html', {'age': age}) 
    return render(request,"age.html")

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            username = request.POST.get('username')

            # Redirect to a success page           
            return render(request,'success.html',{'username' : username})
    else:
        form = UserRegistrationForm()
    return render(request, 'signup.html', {'form': form})

def send_email(request):
    send_mail(
        'Welcome Party - reg.',
        'Greetings!!! Welcome to the Department of Information Technology.',
        settings.EMAIL_HOST_USER,
        ['kabileshk2003@gmail.com'],
        fail_silently=False,
    )
    return render(request, 'sendMail.html')

def create(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        MyModel.objects.create(name=name, description=description)
        return HttpResponse("Record created successfully")
    return render(request, 'create.html')


def read(request):
    objects = MyModel.objects.all()
    return render(request, 'read.html', {'objects': objects})


def update(request, pk):
    instance = get_object_or_404(MyModel, pk=pk)
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        instance.name = name
        instance.description = description
        instance.save()
        return HttpResponse("Record updated successfully")
    return render(request, 'update.html', {'instance': instance})


def delete(request, pk):
    instance = get_object_or_404(MyModel, pk=pk)
    if request.method == 'POST':
        instance.delete()
        return HttpResponse("Record deleted successfully")
    return render(request, 'delete.html', {'instance': instance})
    

